@extends('layouts.admin.app')

@section('content')
<div class="container-fluid px-4">
    <!-- Breadcrumb & Title -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Family Tree Builder</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                </ol>
            </nav>
            <h4 class="mb-0">Welcome, Jason.</h4>
            <small>Hello, here you can manage your orders by zone.</small>
        </div>
        <div class="d-flex gap-2">
            <select class="form-select form-select-sm" style="width: auto;">
                <option selected>All Zones</option>
                <!-- Add more options as needed -->
            </select>
        </div>
    </div>

    <!-- Order Statistics -->
    <div class="mb-4">
        <h5 class="mb-3">Order Statistics <span class="badge bg-secondary">Zone : All</span></h5>
        <div class="row g-3">
            @php
                $stats = [
                    ['Delivered Orders', 'success'],
                    ['Canceled Orders', 'danger'],
                    ['Refunded Orders', 'warning'],
                    ['Payment Failed Orders', 'danger'],
                    ['Unassigned Orders', 'light'],
                    ['Accepted By Delivery Man', 'light'],
                    ['Cooking In Restaurant', 'light'],
                    ['Picked Up By Delivery Man', 'light'],
                ];
            @endphp
            @foreach ($stats as $stat)
                <div class="col-md-3">
                    <div class="card text-center bg-{{ $stat[1] }}">
                        <div class="card-body">
                            <h5 class="card-title mb-1">0</h5>
                            <p class="card-text small">{{ $stat[0] }}</p>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    <!-- Customer & Users -->
    <div class="mb-4">
        <h5 class="mb-3">Customer & Users</h5>
        <div class="row g-3">
            <div class="col-md-6">
                <div class="card bg-success text-white text-center">
                    <div class="card-body">
                        <h5 class="card-title mb-1">0</h5>
                        <p class="card-text small">New Customers</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-danger text-white text-center">
                    <div class="card-body">
                        <h5 class="card-title mb-1">0</h5>
                        <p class="card-text small">New Users</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Placeholder Chart or Summary -->
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between">
                <div>
                    <span class="badge bg-primary">Admin commission: $139</span>
                    <span class="badge bg-info text-dark">Total Sell: $694</span>
                    <span class="badge bg-success">Subscription: $40</span>
                </div>
                <div>
                    <select class="form-select form-select-sm d-inline-block" style="width: auto;">
                        <option>Daily</option>
                        <option>Weekly</option>
                        <option>Monthly</option>
                    </select>
                </div>
            </div>
            <div class="mt-4" style="height: 250px;">
                <!-- Chart.js or other chart can go here -->
                <div class="text-center text-muted pt-5">Chart Placeholder</div>
            </div>
        </div>
    </div>
</div>
@endsection
