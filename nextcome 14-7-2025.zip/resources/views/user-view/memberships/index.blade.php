@extends('layouts.user.app')

@section('content')
<style>
    @media (min-width: 1200px) {
        .pricing-header {
            max-width: 100% !important;
        }
    }

    .pricing-features li {
        text-align: center
    }
</style>
<div class="main-content right-chat-active">
    <div class="middle-sidebar-bottom">
        <div class="middle-sidebar-left pe-0">
            <div class="container py-5">
                <h2 class="text-center"> {{ __('messages.Choose Your Pricing') }}</h2>
                <p class="text-center text-muted mb-5"> {{ __('messages.Simple, flexible and predictable pricing.') }}</p>

                <div class="row justify-content-center g-4">

                    <!-- Free Trial -->
                    @foreach ($plan as $membership)
                    <div class="col-md-3">
                        <div class="pricing-card">
                            <div class="pricing-header text-center">${{ $membership->monthly_price }}/{{ __('messages.month') }}</div>
                            <div class="pricing-body text-center">
                                <div class="pricing-title">
                                    @php
                                    $locale = session('locale', app()->getLocale());
                                    @endphp

                                    @if ($locale === 'ch')
                                    {{ $membership->chinese_name }}
                                    @elseif ($locale === 'ko')
                                    {{ $membership->korean_name }}
                                    @else
                                    {{ $membership->name }}
                                    @endif
                                </div>
                                <ul class="pricing-features text-start">
                                    <li> {{ __('messages.Allow up to') }} {{ $membership->monthly_members }} {{ __('messages.members') }}</li>
                                </ul>
                                <div class="paypal-button">
                                    <a href="{{ route('paypal.subscribe', $membership->id) }}">
                                        <img src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif"
                                            alt="Subscribe with PayPal">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach

                </div>
            </div>
        </div>
    </div>
</div>
@endsection