<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Meta -->
    <meta name="description" content="Responsive Bootstrap 4 Dashboard and Admin Template">
    <meta name="author" content="ThemePixels">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('assets/front-end/images/nextcome_favicone.png') }}">

    <title>NEXTCOME - Family Tree Creator</title>

    <!-- vendor css -->
    <link href="{{ asset('assets/back-end/lib/@fortawesome/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/back-end/lib/ionicons/css/ionicons.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/back-end/lib/prismjs/themes/prism-tomorrow.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/back-end/lib/datatables.net-dt/css/jquery.dataTables.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/back-end/lib/datatables.net-responsive-dt/css/responsive.dataTables.min.css') }}"
        rel="stylesheet">
    <link href="{{ asset('assets/back-end/lib/select2/css/select2.min.css') }}" rel="stylesheet">

    <!-- template css -->
    <link rel="stylesheet" href="{{ asset('assets/back-end/assets/css/cassie.css') }}">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" />
    {{-- DataTables CSS --}}
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">

    {{-- DataTables JS --}}
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        .container {
            margin-left: 30px;
        }

        @media (min-width: 1400px) {

            .container,
            .container-lg,
            .container-md,
            .container-sm,
            .container-xl,
            .container-xxl {
                max-width: 1245px;
            }
        }
    </style>
    <style>
        .pricing-card {
            border: 1px solid #dee2e6;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease;
        }

        .pricing-card:hover {
            transform: translateY(-5px);
        }

        .pricing-header {
            background-color: #00a6c4;
            color: #fff;
            padding: 20px 10px;
            font-size: 24px;
            font-weight: bold;
        }

        .pricing-body {
            padding: 20px;
        }

        .pricing-title {
            font-size: 20px;
            font-weight: bold;
            color: #0056b3;
            margin-bottom: 10px;
            border-bottom: 1px dotted #aaa;
            display: inline-block;
        }

        .current-plan {
            font-weight: bold;
            color: #007bff;
            text-align: center;
            margin-top: 15px;
        }

        .paypal-button {
            margin-top: 20px;
            text-align: center;
        }

        .paypal-button img {
            height: 40px;
        }

        .pricing-features {
            list-style: none;
            padding-left: 0;
            margin-top: 15px;
            margin-bottom: 0;
        }

        .pricing-features li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    @include('layouts.admin.header')

    @yield('content')



    <script src="{{ asset('assets/back-end/lib/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/back-end/lib/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('assets/back-end/lib/feather-icons/feather.min.js') }}"></script>
    <script src="{{ asset('assets/back-end/lib/perfect-scrollbar/perfect-scrollbar.min.js') }}"></script>
    <script src="{{ asset('assets/back-end/lib/js-cookie/js.cookie.js') }}"></script>
    <script src="{{ asset('assets/back-end/js/svg-inline.js') }}"></script>
    <script src="{{ asset('assets/back-end/assets/js/cassie.js') }}"></script>
    <script src="{{ asset('assets/back-end/lib/prismjs/prism.js') }}"></script>
    <script src="{{ asset('assets/back-end/lib/datatables.net/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/back-end/lib/datatables.net-dt/js/dataTables.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/back-end/lib/datatables.net-responsive/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('assets/back-end/lib/datatables.net-responsive-dt/js/responsive.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/back-end/lib/select2/js/select2.min.js') }}"></script>
    <script>
        document.querySelectorAll('.language-option').forEach(item => {
            item.addEventListener('click', event => {
                event.preventDefault();
                const selectedLanguage = event.currentTarget.innerHTML;
                document.querySelector('.current-language').innerHTML = selectedLanguage;

                // Add your code to handle the language change
            });
        });
    </script>
    <!-- Page-specific scripts -->
    @stack('script')
    @yield('scripts')
    <!-- Bootstrap 5 JS Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    @if (session('success'))
    <script>
        toastr.success("{{ session('success') }}", 'Success', {
            timeOut: 5000
        });
    </script>
    @endif

    @if (session('error'))
    <script>
        toastr.error("{{ session('error') }}", 'Error', {
            timeOut: 5000
        });
    </script>
    @endif
</body>

</html>