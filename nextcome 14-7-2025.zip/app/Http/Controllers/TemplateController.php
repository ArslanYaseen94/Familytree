<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TemplateController extends Controller
{
    public function templates()
    {

        return view("admin-view.template.index");
    }

    public function templateuser()
    {
        return view("user-view.configuration.templates");
    }

    public function storetemplate(Request $request)
    {
        // dd($request->all());
        $user = Auth::user(); // Get the authenticated user

        // Update the 'template' attribute of the user
        $user->template = $request->input("template");
        $user->has_image = $request->has("contains_user_image") ? 1 : 0;
        $user->save(); // Save the changes to the user model

        return redirect()->back()
        ->with(__('messages.success'), __('messages.Template Updated Successfully'));
    }
}
