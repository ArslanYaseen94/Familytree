<?php

namespace App\Http\Controllers;

use App\Models\Plan;
use Illuminate\Http\Request;

class MembershipController extends Controller
{
    public function index(){

        $plan = Plan::get();
        return view("user-view.memberships.index",compact("plan"));
    }
}
